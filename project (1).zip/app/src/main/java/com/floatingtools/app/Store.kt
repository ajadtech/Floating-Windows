package com.floatingtools.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.Drawable

object Store {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("ft", 0)

    fun saved(c: Context): List<String> =
        sp(c).getString("saved", "")!!.split("\n").filter { it.isNotBlank() }

    fun add(c: Context, pkg: String) {
        val l = saved(c).toMutableList()
        if (pkg !in l) {
            l.add(pkg)
            sp(c).edit().putString("saved", l.joinToString("\n")).apply()
        }
    }

    fun remove(c: Context, pkg: String) {
        val l = saved(c).filter { it != pkg }
        sp(c).edit().putString("saved", l.joinToString("\n")).apply()
    }

    fun info(c: Context, pkg: String): Pair<String, Drawable>? = try {
        val pm = c.packageManager
        Pair(pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(), pm.getApplicationIcon(pkg))
    } catch (e: Exception) {
        null
    }
}

object WebMap {
    private val map = mapOf(
        "com.facebook.katana" to "https://m.facebook.com",
        "com.facebook.lite" to "https://m.facebook.com",
        "com.facebook.orca" to "https://www.messenger.com",
        "com.facebook.mlite" to "https://www.messenger.com",
        "com.instagram.android" to "https://www.instagram.com",
        "com.twitter.android" to "https://x.com",
        "com.google.android.youtube" to "https://m.youtube.com",
        "com.google.android.apps.youtube.music" to "https://music.youtube.com",
        "org.telegram.messenger" to "https://web.telegram.org",
        "com.whatsapp" to "https://web.whatsapp.com",
        "com.whatsapp.w4b" to "https://web.whatsapp.com",
        "com.zhiliaoapp.musically" to "https://www.tiktok.com",
        "com.ss.android.ugc.trill" to "https://www.tiktok.com",
        "com.snapchat.android" to "https://web.snapchat.com",
        "com.linkedin.android" to "https://www.linkedin.com",
        "com.reddit.frontpage" to "https://www.reddit.com",
        "com.pinterest" to "https://www.pinterest.com",
        "com.spotify.music" to "https://open.spotify.com",
        "com.discord" to "https://discord.com/app",
        "com.netflix.mediaclient" to "https://www.netflix.com",
        "com.google.android.gm" to "https://mail.google.com",
        "com.google.android.apps.maps" to "https://www.google.com/maps",
        "com.google.android.apps.photos" to "https://photos.google.com",
        "com.google.android.apps.docs" to "https://drive.google.com",
        "com.google.android.calendar" to "https://calendar.google.com",
        "com.google.android.keep" to "https://keep.google.com",
        "com.google.android.apps.translate" to "https://translate.google.com",
        "com.google.android.googlequicksearchbox" to "https://www.google.com",
        "com.android.chrome" to "https://www.google.com",
        "com.android.vending" to "https://play.google.com/store",
        "com.openai.chatgpt" to "https://chatgpt.com",
        "com.anthropic.claude" to "https://claude.ai",
        "com.imo.android.imoim" to "https://imo.im",
        "com.skype.raider" to "https://web.skype.com",
        "com.microsoft.teams" to "https://teams.microsoft.com",
        "com.microsoft.office.outlook" to "https://outlook.live.com",
        "us.zoom.videomeetings" to "https://app.zoom.us/wc",
        "org.wikipedia" to "https://www.wikipedia.org",
        "com.amazon.mShop.android.shopping" to "https://www.amazon.com",
        "com.daraz.android" to "https://www.daraz.com.bd",
        "com.quora.android" to "https://www.quora.com",
        "com.medium.reader" to "https://medium.com",
        "com.github.android" to "https://github.com"
    )

    fun url(pkg: String): String? = map[pkg]
}
