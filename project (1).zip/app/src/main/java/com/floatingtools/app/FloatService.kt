package com.floatingtools.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT

class FloatService : Service() {
    private class Win(
        val root: FrameLayout,
        val web: WebView,
        val p: WindowManager.LayoutParams,
        val bubble: View,
        val bp: WindowManager.LayoutParams
    ) {
        var min = false
    }

    private lateinit var wm: WindowManager
    private val wins = LinkedHashMap<String, Win>()
    private var handle: View? = null
    private var handleP: WindowManager.LayoutParams? = null
    private var panel: View? = null

    private val fNF = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    private val fNTM = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notif())
        if (!::wm.isInitialized) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            addHandle()
            Store.sp(this).edit().putBoolean("svc", true).apply()
        }
        when (intent?.action) {
            "open" -> intent.getStringExtra("pkg")?.let { openApp(it) }
            "refresh" -> hidePanel()
        }
        return START_STICKY
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun rm(v: View?) {
        if (v != null && ::wm.isInitialized) {
            try { wm.removeView(v) } catch (e: Exception) {}
        }
    }

    private fun lp(w: Int, h: Int, flags: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(w, h, type, flags, PixelFormat.TRANSLUCENT)
    }

    private fun notif(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("float", "Floating", NotificationManager.IMPORTANCE_LOW))
            return Notification.Builder(this, "float")
                .setContentTitle("Floating Tools চালু আছে")
                .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
        }
        return Notification.Builder(this)
            .setContentTitle("Floating Tools চালু আছে")
            .setSmallIcon(android.R.drawable.ic_menu_info_details).build()
    }

    // ---------- generic drag ----------
    private fun drag(v: View, target: () -> View, p: WindowManager.LayoutParams, lockX: Boolean, onTap: () -> Unit) {
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        if (!lockX) p.x = sx + dx.toInt()
                        p.y = (sy + dy.toInt()).coerceAtLeast(0)
                        try { wm.updateViewLayout(target(), p) } catch (e2: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap()
                }
            }
            true
        }
    }

    // ---------- side handle + panel ----------
    private fun addHandle() {
        val h = View(this)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#B3263238"))
        val r = dp(8).toFloat()
        bg.cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        h.background = bg
        val p = lp(dp(14), dp(90), fNF or fNTM)
        p.gravity = Gravity.TOP or Gravity.END
        p.y = dp(260)
        drag(h, { h }, p, true) { togglePanel() }
        wm.addView(h, p)
        handle = h
        handleP = p
    }

    private fun togglePanel() {
        if (panel != null) hidePanel() else showPanel()
    }

    private fun hidePanel() {
        rm(panel)
        panel = null
    }

    private fun showPanel() {
        val list = Store.saved(this).filter { Store.info(this, it) != null }
        if (list.isEmpty()) {
            toast("Profile-এ কোনো অ্যাপ নেই")
            return
        }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(6), dp(6), dp(6), dp(6))
        for (pkg in list) {
            val iv = ImageView(this)
            iv.setImageDrawable(Store.info(this, pkg)!!.second)
            iv.setOnClickListener {
                hidePanel()
                openApp(pkg)
            }
            val lpi = LinearLayout.LayoutParams(dp(44), dp(44))
            lpi.setMargins(0, dp(3), 0, dp(3))
            col.addView(iv, lpi)
        }
        val sv = ScrollView(this)
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#E6263238"))
        bg.cornerRadius = dp(14).toFloat()
        sv.background = bg
        sv.addView(col)
        sv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) hidePanel()
            false
        }
        val h = minOf(list.size * dp(50) + dp(12), dp(360))
        val p = lp(dp(60), h, fNF or fNTM or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH)
        p.gravity = Gravity.TOP or Gravity.END
        p.x = dp(18)
        p.y = handleP?.y ?: dp(260)
        wm.addView(sv, p)
        panel = sv
    }

    // ---------- floating windows ----------
    private fun openApp(pkg: String) {
        val url = WebMap.url(pkg)
        val info = Store.info(this, pkg)
        if (url == null || info == null) {
            toast("এই অ্যাপের ওয়েব ভার্সন নেই")
            return
        }
        val ex = wins[pkg]
        if (ex != null) {
            if (ex.min) restore(pkg, ex) else front(pkg, ex)
            return
        }
        if (wins.size >= 4) {
            toast("সর্বোচ্চ ৪টি উইন্ডো একসাথে চলবে")
            return
        }
        createWin(pkg, url, info.first, info.second)
    }

    private fun createWin(pkg: String, url: String, label: String, icon: Drawable) {
        val dm = resources.displayMetrics
        val root = FrameLayout(this)
        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        bg.cornerRadius = dp(16).toFloat()
        root.background = bg
        root.clipToOutline = true
        root.elevation = dp(8).toFloat()

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#263238"))
        bar.setPadding(dp(10), 0, 0, 0)
        val ic = ImageView(this)
        ic.setImageDrawable(icon)
        bar.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))
        val title = TextView(this)
        title.text = label
        title.setTextColor(Color.WHITE)
        title.textSize = 14f
        title.setSingleLine()
        val tlp = LinearLayout.LayoutParams(0, MP, 1f)
        tlp.leftMargin = dp(8)
        tlp.gravity = Gravity.CENTER_VERTICAL
        bar.addView(title, tlp)
        title.gravity = Gravity.CENTER_VERTICAL
        val minBtn = btn("—")
        val closeBtn = btn("✕")
        bar.addView(minBtn, LinearLayout.LayoutParams(dp(42), MP))
        bar.addView(closeBtn, LinearLayout.LayoutParams(dp(42), MP))
        col.addView(bar, LinearLayout.LayoutParams(MP, dp(44)))

        val web = WebView(this)
        web.setBackgroundColor(Color.WHITE)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.userAgentString = web.settings.userAgentString.replace("; wv", "")
        web.webViewClient = WebViewClient()
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.loadUrl(url)
        col.addView(web, LinearLayout.LayoutParams(MP, 0, 1f))

        val hl = cornerView("◣")
        val hr = cornerView("◢")
        root.addView(col, FrameLayout.LayoutParams(MP, MP))
        root.addView(hl, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM or Gravity.START))
        root.addView(hr, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM or Gravity.END))

        val n = wins.size
        val w = minOf(dm.widthPixels - dp(24), dp(340))
        val h = minOf((dm.heightPixels * 0.6).toInt(), dp(480))
        val p = lp(w, h, fNTM)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = dp(12) + n * dp(16)
        p.y = dp(80) + n * dp(24)

        val bubble = ImageView(this)
        bubble.setImageDrawable(icon.constantState?.newDrawable() ?: icon)
        bubble.setPadding(dp(8), dp(8), dp(8), dp(8))
        val bb = GradientDrawable()
        bb.shape = GradientDrawable.OVAL
        bb.setColor(Color.WHITE)
        bubble.background = bb
        bubble.elevation = dp(6).toFloat()
        val bp = lp(dp(52), dp(52), fNF or fNTM)
        bp.gravity = Gravity.TOP or Gravity.START

        val win = Win(root, web, p, bubble, bp)
        wins[pkg] = win
        drag(bar, { root }, p, false) { front(pkg, win) }
        drag(bubble, { bubble }, bp, false) { restore(pkg, win) }
        hl.setOnTouchListener(corner(win, true))
        hr.setOnTouchListener(corner(win, false))
        minBtn.setOnClickListener { minimize(win) }
        closeBtn.setOnClickListener { close(pkg, win) }
        wm.addView(root, p)
    }

    private fun btn(t: String): TextView {
        val b = TextView(this)
        b.text = t
        b.setTextColor(Color.WHITE)
        b.textSize = 17f
        b.gravity = Gravity.CENTER
        return b
    }

    private fun cornerView(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 16f
        v.setTextColor(Color.GRAY)
        v.gravity = Gravity.CENTER
        return v
    }

    private fun corner(w: Win, left: Boolean): View.OnTouchListener {
        var sx = 0f
        var sy = 0f
        var sw = 0
        var sh = 0
        var spx = 0
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; sw = w.p.width; sh = w.p.height; spx = w.p.x
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    val dm = resources.displayMetrics
                    val nw = (if (left) sw - dx else sw + dx).coerceIn(dp(180), dm.widthPixels)
                    val nh = (sh + dy).coerceIn(dp(160), dm.heightPixels)
                    if (left) w.p.x = spx + (sw - nw)
                    w.p.width = nw
                    w.p.height = nh
                    try { wm.updateViewLayout(w.root, w.p) } catch (e2: Exception) {}
                }
            }
            true
        }
    }

    private fun front(pkg: String, w: Win) {
        if (wins.keys.last() == pkg) return
        wins.remove(pkg)
        wins[pkg] = w
        rm(w.root)
        wm.addView(w.root, w.p)
    }

    private fun minimize(w: Win) {
        rm(w.root)
        w.min = true
        w.web.onPause()
        w.bp.x = w.p.x
        w.bp.y = w.p.y
        wm.addView(w.bubble, w.bp)
    }

    private fun restore(pkg: String, w: Win) {
        rm(w.bubble)
        w.min = false
        w.web.onResume()
        wins.remove(pkg)
        wins[pkg] = w
        wm.addView(w.root, w.p)
    }

    private fun close(pkg: String, w: Win) {
        rm(if (w.min) w.bubble else w.root)
        (w.web.parent as? ViewGroup)?.removeView(w.web)
        w.web.destroy()
        wins.remove(pkg)
    }

    override fun onDestroy() {
        if (::wm.isInitialized) {
            hidePanel()
            rm(handle)
            for (w in wins.values) {
                rm(if (w.min) w.bubble else w.root)
                (w.web.parent as? ViewGroup)?.removeView(w.web)
                w.web.destroy()
            }
            wins.clear()
        }
        Store.sp(this).edit().putBoolean("svc", false).apply()
        CookieManager.getInstance().flush()
        super.onDestroy()
    }
}
