package com.floatingtools.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {
    class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private lateinit var content: FrameLayout
    private lateinit var tabHome: TextView
    private lateinit var tabProfile: TextView
    private var apps = listOf<AppItem>()
    private var shown = listOf<AppItem>()
    private val blue = Color.parseColor("#1877F2")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int): Any = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val a = shown[i]
            val web = WebMap.url(a.pkg) != null
            return row(a.icon, a.label, if (web) "Web ✓" else "Web নেই", null)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        val rootV = LinearLayout(this)
        rootV.orientation = LinearLayout.VERTICAL
        rootV.setBackgroundColor(Color.WHITE)

        val header = TextView(this)
        header.text = "Floating Tools"
        header.textSize = 20f
        header.setTypeface(null, Typeface.BOLD)
        header.setTextColor(Color.WHITE)
        header.setBackgroundColor(Color.parseColor("#263238"))
        header.setPadding(dp(16), dp(14), dp(16), dp(14))

        content = FrameLayout(this)

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(Color.WHITE)
        nav.elevation = dp(8).toFloat()
        tabHome = tab("🏠  Home") { show(0) }
        tabProfile = tab("👤  Profile") { show(1) }
        nav.addView(tabHome, LinearLayout.LayoutParams(0, MP, 1f))
        nav.addView(tabProfile, LinearLayout.LayoutParams(0, MP, 1f))

        rootV.addView(header, LinearLayout.LayoutParams(MP, WC))
        rootV.addView(content, LinearLayout.LayoutParams(MP, 0, 1f))
        rootV.addView(nav, LinearLayout.LayoutParams(MP, dp(56)))
        setContentView(rootV)
        show(0)
        loadApps()
    }

    private fun tab(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 15f
        t.gravity = Gravity.CENTER
        t.setOnClickListener { onClick() }
        return t
    }

    private fun show(i: Int) {
        tabHome.setTextColor(if (i == 0) blue else Color.GRAY)
        tabProfile.setTextColor(if (i == 1) blue else Color.GRAY)
        tabHome.setTypeface(null, if (i == 0) Typeface.BOLD else Typeface.NORMAL)
        tabProfile.setTypeface(null, if (i == 1) Typeface.BOLD else Typeface.NORMAL)
        content.removeAllViews()
        content.addView(if (i == 0) homeView() else profileView())
    }

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .filter { it.pkg != packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                apps = list
                shown = list
                adapter.notifyDataSetChanged()
            }
        }.start()
    }

    private fun homeView(): View {
        shown = apps
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val search = EditText(this)
        search.hint = "অ্যাপ খুঁজুন..."
        search.setSingleLine()
        search.setPadding(dp(16), dp(12), dp(16), dp(12))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty()
                shown = apps.filter { it.label.contains(q, true) }
                adapter.notifyDataSetChanged()
            }
        })
        val list = ListView(this)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ -> if (i < shown.size) confirm(shown[i]) }
        col.addView(search, LinearLayout.LayoutParams(MP, WC))
        col.addView(list, LinearLayout.LayoutParams(MP, 0, 1f))
        return col
    }

    private fun confirm(a: AppItem) {
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setIcon(a.icon)
            .setMessage("এই অ্যাপের ওয়েব ভার্সন Floating হিসেবে চালু করবেন?")
            .setPositiveButton("Create Floating") { _, _ -> create(a) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun create(a: AppItem) {
        if (WebMap.url(a.pkg) == null) {
            AlertDialog.Builder(this)
                .setTitle(a.label)
                .setMessage("Sorry, this app isn't allow web version, try another app.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        Store.add(this, a.pkg)
        if (startOpen(a.pkg)) {
            Toast.makeText(this, "Floating তৈরি হয়েছে, Profile-এ দেখুন", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askOverlay() {
        Toast.makeText(this, "\"Display over other apps\" চালু করে ফিরে এসে আবার চাপুন", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun startOpen(pkg: String): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            askOverlay()
            return false
        }
        startSvc("open", pkg)
        return true
    }

    private fun startSvc(action: String, pkg: String? = null) {
        val i = Intent(this, FloatService::class.java).setAction(action)
        if (pkg != null) i.putExtra("pkg", pkg)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
    }

    private fun profileView(): View {
        val sc = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(0, dp(8), 0, dp(8))
        val running = Store.sp(this).getBoolean("svc", false)

        val sw = Switch(this)
        sw.text = "Side Handle (ডান পাশের স্লাইড বার)"
        sw.setPadding(dp(16), dp(12), dp(16), dp(12))
        sw.isChecked = running
        sw.setOnCheckedChangeListener { b, on ->
            if (on) {
                if (!Settings.canDrawOverlays(this)) {
                    b.isChecked = false
                    askOverlay()
                } else startSvc("refresh")
            } else stopService(Intent(this, FloatService::class.java))
        }
        col.addView(sw, LinearLayout.LayoutParams(MP, WC))

        var count = 0
        for (pkg in Store.saved(this)) {
            val info = Store.info(this, pkg) ?: continue
            count++
            val x = TextView(this)
            x.text = "✕"
            x.textSize = 18f
            x.setTextColor(Color.GRAY)
            x.setPadding(dp(12), dp(8), dp(4), dp(8))
            x.setOnClickListener {
                Store.remove(this, pkg)
                if (Store.sp(this).getBoolean("svc", false)) startSvc("refresh")
                show(1)
            }
            val r = row(info.second, info.first, "চাপলে Floating খুলবে", x)
            r.setOnClickListener { startOpen(pkg) }
            col.addView(r, LinearLayout.LayoutParams(MP, WC))
        }
        if (count == 0) {
            val t = TextView(this)
            t.text = "এখনো কোনো Floating অ্যাপ নেই।\nHome থেকে অ্যাপ বেছে Create Floating চাপুন।"
            t.setTextColor(Color.GRAY)
            t.setPadding(dp(16), dp(24), dp(16), dp(24))
            col.addView(t)
        }
        sc.addView(col)
        return sc
    }

    private fun row(icon: Drawable, title: String, sub: String, trailing: View?): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(14), dp(10), dp(14), dp(10))
        val iv = ImageView(this)
        iv.setImageDrawable(icon)
        r.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        val a = TextView(this)
        a.text = title
        a.textSize = 16f
        a.setTextColor(Color.BLACK)
        val b = TextView(this)
        b.text = sub
        b.textSize = 12f
        b.setTextColor(Color.GRAY)
        t.addView(a)
        t.addView(b)
        val tl = LinearLayout.LayoutParams(0, WC, 1f)
        tl.leftMargin = dp(14)
        r.addView(t, tl)
        if (trailing != null) r.addView(trailing)
        return r
    }
}
